package petShop.api.domain.agenda;

public record AgendaDiaDTO(String data, String hora, String nomeAnimal, String servico) {}
