package petShop.api.domain.consulta;

public enum TipoConsulta {
    CONSULTA,
    RETORNO,
    VACINACAO
}