package petShop.api.domain.agenda;

public record HorarioDTO(String data, String hora) {}