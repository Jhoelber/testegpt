package petShop.api.infra.security;

public record DadosTokenJWT(String token) {
}
