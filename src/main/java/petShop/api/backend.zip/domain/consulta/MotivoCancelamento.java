package petShop.api.domain.consulta;

public enum MotivoCancelamento {

    PACIENTE_DESISTIU,
   VETERINARIO_CANCELOU,
    OUTROS;

}
