package petShop.api.domain.venda;

public enum TipoVenda {
    PRODUTO,
    SERVIÇO,
    AMBOS
}
