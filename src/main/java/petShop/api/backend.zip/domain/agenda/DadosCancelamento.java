package petShop.api.domain.agenda;

public record DadosCancelamento(Long agendamentoId, String motivo) {

}
