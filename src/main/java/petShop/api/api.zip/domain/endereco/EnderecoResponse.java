package petShop.api.domain.endereco;

public record EnderecoResponse() {
}
