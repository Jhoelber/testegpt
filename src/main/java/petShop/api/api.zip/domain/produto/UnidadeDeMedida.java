package petShop.api.domain.produto;

public enum UnidadeDeMedida {

    kg,
    g,
    l,
    ml,
    unidade,
    pacote,
    caixa,
    litro,
    metro,
    metroQuadrado,
    serviço

}