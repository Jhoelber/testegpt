package petShop.api.domain.consulta;

import java.time.LocalDateTime;

public record ConsultaAgendaDTO(
        String nomeAnimal,
        String nomeCliente,
        LocalDateTime data
) {
}